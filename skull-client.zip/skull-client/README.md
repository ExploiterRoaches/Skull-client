# Skull Client

A modular utility client for **Minecraft 1.21.1** (Fabric): ClickGUI, HUD, chat commands, saved settings.

> Source was syntax-checked and cross-reference-checked, but has not been compiled against Minecraft or run in-game by the author. See "Troubleshooting".

## Requirements

- Minecraft Java **1.21.1** (exactly; the mod refuses to load on other versions)
- Fabric Loader **0.16.x** and Fabric API **0.104.0+1.21.1** (or newer 1.21.1 build)
- JDK **21** to build

## Build

```
gradle wrapper --gradle-version 8.10    # one time, needs Gradle installed (or just open the folder in IntelliJ IDEA)
./gradlew build                         # Windows: gradlew.bat build
```
Jar: `build/libs/skullclient-1.0.0.jar` (not the `-sources` one). Put it in `.minecraft/mods` next to Fabric API. Dev test: `./gradlew runClient`.

## Controls

- **Right Shift**: ClickGUI (left-click toggles a module, right-click expands settings)
- Keys: KillAura R, ESP J, XRay X, Fullbright B, Scaffold G, Sprint V, Fly F, Speed Z, Zoom C
- Rebind anything with `.bind <module> <key>`

## Chat commands (prefix `.`, never sent to the server)

| Command | Does |
|---|---|
| `.help` | list commands |
| `.modules` | list modules (green = on) |
| `.toggle <module>` | toggle (`.t`) |
| `.settings <module>` | show settings |
| `.set <module> <setting> <value>` | change a setting |
| `.bind <module> <key\|none>` | set a keybind |
| `.save` | save config now |

Start a message with `..` to send a normal chat message that begins with a dot.

## Modules

**Combat**: KillAura (+TriggerBot mode), AutoArmor, AutoHeal, AutoTotem
**Player**: AutoEat, AutoRespawn, AutoTool, AntiAFK, NoFall
**Movement**: Sprint, Fly, Speed, Step, Parkour, AutoWalk
**Render**: ESP (boxes/glow/tracers), Nametags (name, health, distance), BlockESP (ores/chests through walls), XRay (hides non-whitelisted blocks), Fullbright, Zoom, HUD (watermark, coords, FPS, module list)
**World**: Scaffold

Tip: BlockESP needs no rendering tricks. If XRay misbehaves with your setup, use BlockESP instead.

## Config

`.minecraft/config/utilclient.json` stores keybinds and settings (saved on quit, on closing the ClickGUI, or `.save`). Delete it to reset. Enabled state is not saved.

## Stability design

- Only **one** mixin (XRay). ESP glow, Fullbright, zoom, commands and everything else use plain game/Fabric APIs.
- Mixin config is `required: false` with `defaultRequire: 0`: if it can't apply, XRay just does nothing.
- Modules are built one by one; a broken one is skipped instead of stopping the rest.
- A module that throws is switched off with a red chat message, never crashing the game.
- On quit every module is disabled first so FOV, step height, held keys and glow flags are restored.

## Troubleshooting

- **Crash on launch**: open `.minecraft/crash-reports/` (newest) or `logs/latest.log` and look at the first "Caused by". Lines tagged `[UtilClient]` name the module.
- **"Incompatible mods" screen**: you're not on 1.21.1, or Fabric API / Loader is missing or old.
- **Build error naming a Minecraft method**: names differ in your exact version; small fix on that line.
- **XRay shows nothing/glitches**: toggle off/on; try BlockESP.
- Fly/Speed/NoFall/Step/Scaffold are flagged by most server anti-cheats.

## Layout

```
core/     Module, ModuleInfo, ModuleManager, Category, Config, Commands
setting/  Bool, Number, Mode, BlockList
event/    EventBus + Tick / RenderWorld / RenderHud / Packet events
module/   combat, player, movement, render, world
mixin/    BlockMixin (XRay only)
ui/       ClickGuiScreen
util/     Rotation, Move, Projection, Render helpers
```
Add a module: extend `Module`, annotate `@ModuleInfo(...)`, add `YourModule::new` to `FACTORIES` in `ModuleManager`.

## Fair play

For singleplayer, your own server, or servers that allow client mods. Most public servers prohibit these features and ban accounts that use them.
