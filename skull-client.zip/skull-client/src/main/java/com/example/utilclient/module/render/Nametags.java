package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.RenderHudEvent;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.ProjectionUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleInfo(name = "Nametags", category = Category.RENDER, desc = "Name, health and distance above entities, drawn on the HUD.")
public class Nametags extends Module {
    private final NumberSetting range    = add(new NumberSetting("Range", 64, 8, 256, 4));
    private final BoolSetting players    = add(new BoolSetting("Players", true));
    private final BoolSetting mobs       = add(new BoolSetting("Mobs", false));
    private final BoolSetting health     = add(new BoolSetting("Health", true));
    private final BoolSetting distance   = add(new BoolSetting("Distance", true));

    @Subscribe
    private void onHud(RenderHudEvent e) {
        if (mc.options.hudHidden || mc.world == null || mc.player == null) return;

        float td = mc.getRenderTickCounter().getTickDelta(false);
        var camera = mc.gameRenderer.getCamera();
        Vec3d cam = camera.getPos();
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double fov = mc.options.getFov().getValue();

        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof LivingEntity le) || en == mc.player || !le.isAlive()) continue;
            if (!((en instanceof PlayerEntity && players.get()) || (en instanceof MobEntity && mobs.get()))) continue;
            if (mc.player.distanceTo(en) > range.get()) continue;

            Vec3d rel = new Vec3d(
                MathHelper.lerp(td, en.prevX, en.getX()) - cam.x,
                MathHelper.lerp(td, en.prevY, en.getY()) + en.getHeight() + 0.4 - cam.y,
                MathHelper.lerp(td, en.prevZ, en.getZ()) - cam.z);
            double[] s = ProjectionUtil.project(rel, camera.getYaw(), camera.getPitch(), fov, w, h);
            if (s == null) continue;

            float hp = le.getHealth() + le.getAbsorptionAmount();
            StringBuilder sb = new StringBuilder(en.getName().getString());
            if (health.get()) sb.append(String.format(" %.1f", hp));
            if (distance.get()) sb.append(String.format(" [%.0fm]", mc.player.distanceTo(en)));

            int color = hp > 14 ? 0xFF55FF55 : hp > 7 ? 0xFFFFFF55 : 0xFFFF5555;
            String text = sb.toString();
            int tw = mc.textRenderer.getWidth(text);
            int x = (int) s[0], y = (int) s[1];
            e.ctx.fill(x - tw / 2 - 2, y - 2, x + tw / 2 + 2, y + 10, 0x90000000);
            e.ctx.drawCenteredTextWithShadow(mc.textRenderer, text, x, y, color);
        }
    }
}
