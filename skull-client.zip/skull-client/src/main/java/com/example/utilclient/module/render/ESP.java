package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.RenderWorldEvent;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.ModeSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

@ModuleInfo(name = "ESP", category = Category.RENDER, key = GLFW.GLFW_KEY_J, desc = "Boxes or glow outlines, plus tracers.")
public class ESP extends Module {
    private final ModeSetting mode    = add(new ModeSetting("Mode", "Box", "Box", "Outline"));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", true));
    private final NumberSetting range = add(new NumberSetting("Range", 64, 8, 256, 4));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs    = add(new BoolSetting("Mobs", true));

    private final Set<Integer> glowing = new HashSet<>();

    private boolean isTarget(Entity en) {
        if (en == mc.player || mc.player.distanceTo(en) > range.get()) return false;
        return (en instanceof PlayerEntity && players.get()) || (en instanceof MobEntity && mobs.get());
    }

    @Subscribe
    private void onTick(TickEvent e) {
        if (!mode.is("Outline")) { clearGlow(); return; }
        Set<Integer> still = new HashSet<>();
        for (Entity en : mc.world.getEntities()) {
            if (!isTarget(en)) continue;
            if (!en.isGlowing()) en.setGlowing(true);      // client-side flag only
            still.add(en.getId());
        }
        for (int id : new ArrayList<>(glowing)) {
            if (still.contains(id)) continue;
            Entity en = mc.world.getEntityById(id);
            if (en != null) en.setGlowing(false);
            glowing.remove(id);
        }
        glowing.addAll(still);
    }

    private void clearGlow() {
        if (mc.world != null) {
            for (int id : glowing) {
                Entity en = mc.world.getEntityById(id);
                if (en != null) en.setGlowing(false);
            }
        }
        glowing.clear();
    }

    @Override protected void onDisable() { clearGlow(); }

    @Subscribe
    private void onRender(RenderWorldEvent e) {
        var camera = mc.gameRenderer.getCamera();
        Vec3d cam = camera.getPos();
        Vec3d lookFromCamera = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());   // crosshair origin for tracers

        RenderUtil.begin();
        try {
            for (Entity en : mc.world.getEntities()) {
                if (!isTarget(en)) continue;

                double x = MathHelper.lerp(e.tickDelta, en.prevX, en.getX()) - cam.x;
                double y = MathHelper.lerp(e.tickDelta, en.prevY, en.getY()) - cam.y;
                double z = MathHelper.lerp(e.tickDelta, en.prevZ, en.getZ()) - cam.z;
                int color = en instanceof PlayerEntity ? 0xFFFF4040 : 0xFF40FF40;

                if (mode.is("Box")) {
                    Box local = en.getBoundingBox().offset(-en.getX(), -en.getY(), -en.getZ()).offset(x, y, z);
                    RenderUtil.drawBox(e.matrices, local, color);
                }
                if (tracers.get())
                    RenderUtil.drawLine(e.matrices, lookFromCamera, new Vec3d(x, y + en.getHeight() / 2, z), color);
            }
        } finally {
            RenderUtil.end();   // never leave depth test / blending in a bad state
        }
    }

    @Override public String hudSuffix() { return mode.get(); }
}
