package com.example.utilclient.module.player;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.util.Stopwatch;

@ModuleInfo(name = "AutoRespawn", category = Category.PLAYER, desc = "Respawns automatically after dying.")
public class AutoRespawn extends Module {
    private final Stopwatch timer = new Stopwatch();

    @Subscribe
    private void onTick(TickEvent e) {
        if (mc.player.isDead() && timer.passed(1000)) {
            mc.player.requestRespawn();
            timer.reset();
        }
    }
}
