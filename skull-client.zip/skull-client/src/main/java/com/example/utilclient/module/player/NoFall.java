package com.example.utilclient.module.player;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

@ModuleInfo(name = "NoFall", category = Category.PLAYER, desc = "Reports you as on-ground when a long fall is about to hurt.")
public class NoFall extends Module {
    private final NumberSetting distance = add(new NumberSetting("MinFall", 2.5, 1.5, 10, 0.5));

    @Subscribe
    private void onTick(TickEvent e) {
        if (mc.player.isOnGround() || mc.player.isFallFlying() || mc.player.getAbilities().flying) return;
        if (mc.player.fallDistance > distance.f())
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
    }
}
