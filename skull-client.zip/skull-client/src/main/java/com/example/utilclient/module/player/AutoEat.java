package com.example.utilclient.module.player;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@ModuleInfo(name = "AutoEat", category = Category.PLAYER, desc = "Eats food from your hotbar when hungry.")
public class AutoEat extends Module {
    private final NumberSetting hunger = add(new NumberSetting("HungerAtOrBelow", 14, 1, 19, 1));
    private final Stopwatch timer = new Stopwatch();

    private boolean eating;
    private int prevSlot = -1;
    private int ticks;

    @Override protected void onDisable() { finish(); }

    @Subscribe
    private void onTick(TickEvent e) {
        if (eating) {
            ticks++;
            if ((mc.player.isUsingItem() && ticks < 100) || ticks < 4) { mc.options.useKey.setPressed(true); return; }
            finish();
            timer.reset();
            return;
        }
        if (mc.currentScreen != null || !timer.passed(500)) return;
        if (mc.player.getHungerManager().getFoodLevel() > hunger.i() || !mc.player.canConsume(false)) return;

        for (int i = 0; i < 9; i++) {
            if (!isGoodFood(mc.player.getInventory().getStack(i))) continue;
            prevSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = i;
            mc.options.useKey.setPressed(true);
            eating = true;
            ticks = 0;
            return;
        }
    }

    private void finish() {
        if (mc.options != null) mc.options.useKey.setPressed(false);
        if (mc.player != null && prevSlot != -1) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1; eating = false; ticks = 0;
    }

    private boolean isGoodFood(ItemStack s) {
        if (s.isEmpty() || !s.contains(DataComponentTypes.FOOD)) return false;
        return !(s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
              || s.isOf(Items.PUFFERFISH) || s.isOf(Items.CHORUS_FRUIT) || s.isOf(Items.SUSPICIOUS_STEW)
              || s.isOf(Items.ENCHANTED_GOLDEN_APPLE));
    }
}
