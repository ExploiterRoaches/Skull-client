package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.RenderWorldEvent;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BlockListSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.BlockPresets;
import com.example.utilclient.util.RenderUtil;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@ModuleInfo(name = "BlockESP", category = Category.RENDER,
            desc = "Outlines ores, chests and portals through walls. No texture/mixin tricks.")
public class BlockESP extends Module {
    private static final int MAX = 1500;

    private record Hit(BlockPos pos, int color) {}

    private final NumberSetting radius      = add(new NumberSetting("Radius", 16, 4, 24, 2));
    private final BlockListSetting blocks   = add(new BlockListSetting("Blocks", BlockPresets.ores()));
    private final Stopwatch scanTimer = new Stopwatch();
    private volatile List<Hit> found = List.of();

    @Override protected void onDisable() { found = List.of(); }

    @Subscribe
    private void onTick(TickEvent e) {
        if (!scanTimer.passed(750)) return;
        scanTimer.reset();

        BlockPos c = mc.player.getBlockPos();
        int r = radius.i();
        List<Hit> out = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        scan:
        for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
                for (int dz = -r; dz <= r; dz++) {
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (mc.world.isOutOfHeightLimit(m.getY())) continue;
                    Block b = mc.world.getBlockState(m).getBlock();
                    if (!blocks.contains(b)) continue;
                    out.add(new Hit(m.toImmutable(), colorOf(b)));
                    if (out.size() >= MAX) break scan;
                }
        found = out;
    }

    @Subscribe
    private void onRender(RenderWorldEvent e) {
        List<Hit> hits = found;
        if (hits.isEmpty()) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        Map<Integer, List<Box>> byColor = new LinkedHashMap<>();
        for (Hit h : hits)
            byColor.computeIfAbsent(h.color, k -> new ArrayList<>())
                   .add(new Box(h.pos).offset(-cam.x, -cam.y, -cam.z));

        RenderUtil.begin();
        try {
            for (var en : byColor.entrySet()) RenderUtil.drawBoxes(e.matrices, en.getValue(), en.getKey());
        } finally {
            RenderUtil.end();
        }
    }

    private static int colorOf(Block b) {
        String id = Registries.BLOCK.getId(b).getPath();
        if (id.contains("diamond")) return 0xFF33E6FF;
        if (id.contains("emerald")) return 0xFF33FF66;
        if (id.contains("gold"))    return 0xFFFFD733;
        if (id.contains("iron"))    return 0xFFE6B98C;
        if (id.contains("copper"))  return 0xFFFF8A4D;
        if (id.contains("redstone"))return 0xFFFF3333;
        if (id.contains("lapis"))   return 0xFF3366FF;
        if (id.contains("coal"))    return 0xFF9A9A9A;
        if (id.contains("debris"))  return 0xFF8B5A3C;
        if (id.contains("quartz"))  return 0xFFF2F2F2;
        if (id.contains("chest"))   return 0xFFFFA500;
        if (id.contains("spawner")) return 0xFFB000FF;
        return 0xFFFFFFFF;
    }
}
