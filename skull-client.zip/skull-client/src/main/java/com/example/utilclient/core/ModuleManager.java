package com.example.utilclient.core;

import com.example.utilclient.module.combat.*;
import com.example.utilclient.module.movement.*;
import com.example.utilclient.module.player.*;
import com.example.utilclient.module.render.*;
import com.example.utilclient.module.world.Scaffold;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final boolean[] KEY_DOWN = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private ModuleManager() {}

    /** Factory-registered: add new modules to this list. Each is constructed inside its own try/catch. */
    private static final List<Supplier<Module>> FACTORIES = List.of(
        // combat
        KillAura::new, AutoArmor::new, AutoHeal::new, AutoTotem::new,
        // player
        AutoEat::new, AutoRespawn::new, AutoTool::new, AntiAFK::new, NoFall::new,
        // movement
        Sprint::new, Fly::new, Speed::new, Step::new, Parkour::new, AutoWalk::new,
        // render
        ESP::new, Nametags::new, BlockESP::new, XRay::new, Fullbright::new, Zoom::new, HUD::new,
        // world
        Scaffold::new
    );

    public static void init() {
        if (!MODULES.isEmpty()) return;
        for (Supplier<Module> f : FACTORIES) {
            try { MODULES.add(f.get()); }
            catch (Throwable t) {
                System.err.println("[UtilClient] A module failed to load and was skipped:");
                t.printStackTrace();
            }
        }
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        return MODULES.stream().filter(m -> m.category == c).toList();
    }

    public static Module find(String name) {
        for (Module m : MODULES) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        throw new IllegalArgumentException("Module not registered: " + type);
    }

    /** Edge-detected keybind polling (no keyboard mixin needed). Call once per tick. */
    public static void pollKeys(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        long handle = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            if (m.key <= 0 || m.key > GLFW.GLFW_KEY_LAST) continue;
            boolean pressed = InputUtil.isKeyPressed(handle, m.key);
            if (pressed && !KEY_DOWN[m.key]) {
                m.toggle();
                if (mc.player != null)
                    mc.player.sendMessage(Text.literal(m.name + (m.isEnabled() ? " \u00a7aON" : " \u00a7cOFF")), true);
            }
            KEY_DOWN[m.key] = pressed;
        }
    }

    /** Disable everything so modules restore FOV, step height, held keys, glow flags, etc. */
    public static void shutdown() {
        for (Module m : MODULES) {
            try { if (m.isEnabled()) m.setEnabled(false); } catch (Throwable ignored) {}
        }
    }
}
