package com.example.utilclient.core;

public enum Category { COMBAT, PLAYER, MOVEMENT, RENDER, WORLD }
