package com.example.utilclient.module.movement;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import net.minecraft.client.option.KeyBinding;

@ModuleInfo(name = "AutoWalk", category = Category.MOVEMENT, desc = "Holds the forward key for you.")
public class AutoWalk extends Module {
    @Subscribe
    private void onTick(TickEvent e) {
        if (mc.currentScreen == null) mc.options.forwardKey.setPressed(true);
    }

    @Override protected void onDisable() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        KeyBinding.updatePressedStates();     // re-apply the real keyboard state (if you're holding W)
    }
}
