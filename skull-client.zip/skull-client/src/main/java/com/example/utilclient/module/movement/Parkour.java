package com.example.utilclient.module.movement;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.util.MoveUtil;
import net.minecraft.util.math.Box;

@ModuleInfo(name = "Parkour", category = Category.MOVEMENT, desc = "Jumps automatically at the edge of a block.")
public class Parkour extends Module {
    @Subscribe
    private void onTick(TickEvent e) {
        if (!mc.player.isOnGround() || mc.player.isSneaking() || !MoveUtil.isMoving()) return;
        Box below = mc.player.getBoundingBox().offset(0, -0.5, 0).expand(-0.001, 0, -0.001);
        if (mc.world.isSpaceEmpty(mc.player, below)) mc.player.jump();
    }
}
