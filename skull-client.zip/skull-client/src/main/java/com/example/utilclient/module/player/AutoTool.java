package com.example.utilclient.module.player;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import net.minecraft.block.BlockState;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

@ModuleInfo(name = "AutoTool", category = Category.PLAYER, desc = "Picks the fastest hotbar tool while you mine.")
public class AutoTool extends Module {
    private int prevSlot = -1;

    @Override protected void onDisable() { restore(); }

    @Subscribe
    private void onTick(TickEvent e) {
        if (mc.currentScreen != null || mc.player.isCreative()) { restore(); return; }

        boolean mining = mc.options.attackKey.isPressed()
                && mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK;
        if (!mining) { restore(); return; }

        BlockState state = mc.world.getBlockState(((BlockHitResult) mc.crosshairTarget).getBlockPos());
        int best = mc.player.getInventory().selectedSlot;
        float bestSpeed = mc.player.getInventory().getStack(best).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            float speed = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) { bestSpeed = speed; best = i; }
        }
        if (best != mc.player.getInventory().selectedSlot) {
            if (prevSlot == -1) prevSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = best;
        }
    }

    private void restore() {
        if (prevSlot != -1 && mc.player != null) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }
}
