package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Fullbright", category = Category.RENDER, key = GLFW.GLFW_KEY_B,
            desc = "Full brightness via a client-side night vision effect.")
public class Fullbright extends Module {
    @Subscribe
    private void onTick(TickEvent e) {
        StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 300)    // refresh only when needed; >200 avoids the fade flicker
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false));
    }

    @Override protected void onDisable() {
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
