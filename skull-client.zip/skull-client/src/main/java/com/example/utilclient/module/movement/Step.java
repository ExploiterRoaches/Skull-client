package com.example.utilclient.module.movement;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

@ModuleInfo(name = "Step", category = Category.MOVEMENT, desc = "Walk up blocks without jumping.")
public class Step extends Module {
    private static final double VANILLA = 0.6;
    private final NumberSetting height = add(new NumberSetting("Height", 1.0, 0.6, 2.5, 0.1));

    @Subscribe
    private void onTick(TickEvent e) {
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.GENERIC_STEP_HEIGHT);
        if (a != null && a.getBaseValue() != height.get()) a.setBaseValue(height.get());
    }

    @Override protected void onDisable() {
        if (mc.player == null) return;
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.GENERIC_STEP_HEIGHT);
        if (a != null) a.setBaseValue(VANILLA);
    }

    @Override public String hudSuffix() { return String.format("%.1f", height.get()); }
}
