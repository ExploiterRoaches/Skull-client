package com.example.utilclient;

import com.example.utilclient.core.Commands;
import com.example.utilclient.core.Config;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleManager;
import com.example.utilclient.event.EventBus;
import com.example.utilclient.event.RenderHudEvent;
import com.example.utilclient.event.RenderWorldEvent;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.ui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class UtilClient implements ClientModInitializer {
    private static final int GUI_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private boolean guiKeyDown;
    private volatile boolean ready;

    @Override
    public void onInitializeClient() {
        // Build modules only after the game is fully started, so MinecraftClient/options are guaranteed to exist.
        ClientLifecycleEvents.CLIENT_STARTED.register(mc -> {
            try {
                ModuleManager.init();
                Config.load();
                Module hud = ModuleManager.find("HUD");
                if (hud != null) hud.setEnabled(true);
                ready = true;
            } catch (Throwable t) {
                System.err.println("[UtilClient] Failed to initialise:");
                t.printStackTrace();
            }
        });

        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (!ready || mc.player == null || mc.world == null) return;
            try {
                ModuleManager.pollKeys(mc);

                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GUI_KEY);
                if (down && !guiKeyDown && mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
                guiKeyDown = down;

                EventBus.post(new TickEvent());
            } catch (Throwable t) { t.printStackTrace(); }
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            if (!ready) return;
            try { EventBus.post(new RenderHudEvent(ctx)); } catch (Throwable t) { t.printStackTrace(); }
        });

        WorldRenderEvents.LAST.register(ctx -> {
            if (!ready || ctx.matrixStack() == null) return;
            try {
                float delta = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
                EventBus.post(new RenderWorldEvent(ctx.matrixStack(), delta));
            } catch (Throwable t) { t.printStackTrace(); }
        });

        // ".command" messages are handled locally and never reach the server
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!ready) return true;
            try { return !Commands.handle(message); }
            catch (Throwable t) { t.printStackTrace(); return true; }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            if (!ready) return;
            try { ModuleManager.shutdown(); } catch (Throwable ignored) {}
            Config.save();
        });
    }
}
