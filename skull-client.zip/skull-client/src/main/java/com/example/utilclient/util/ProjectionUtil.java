package com.example.utilclient.util;

import net.minecraft.util.math.Vec3d;

public final class ProjectionUtil {
    private ProjectionUtil() {}

    /**
     * Projects a camera-relative world offset to scaled-GUI screen coordinates.
     * @return {x, y} or null if the point is behind the camera.
     */
    public static double[] project(Vec3d rel, float camYaw, float camPitch, double fovDeg, int width, int height) {
        Vec3d forward = Vec3d.fromPolar(camPitch, camYaw);
        Vec3d up = Vec3d.fromPolar(camPitch - 90f, camYaw);
        Vec3d right = forward.crossProduct(up);

        double z = rel.dotProduct(forward);
        if (z < 0.1) return null;
        double x = rel.dotProduct(right);
        double y = rel.dotProduct(up);

        double scale = (height / 2.0) / Math.tan(Math.toRadians(fovDeg) / 2.0);
        return new double[] { width / 2.0 + (x / z) * scale, height / 2.0 - (y / z) * scale };
    }
}
