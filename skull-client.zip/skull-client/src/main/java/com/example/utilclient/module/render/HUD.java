package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.core.ModuleManager;
import com.example.utilclient.event.RenderHudEvent;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.setting.BoolSetting;
import net.minecraft.client.font.TextRenderer;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

@ModuleInfo(name = "HUD", category = Category.RENDER, desc = "Watermark, info lines and active-module list.")
public class HUD extends Module {
    private final BoolSetting coords = add(new BoolSetting("Coords", true));
    private final BoolSetting fps    = add(new BoolSetting("FPS", true));
    private final BoolSetting list   = add(new BoolSetting("ModuleList", true));

    @Subscribe
    private void onHud(RenderHudEvent e) {
        if (mc.options.hudHidden || mc.player == null) return;
        TextRenderer font = mc.textRenderer;
        int width = mc.getWindow().getScaledWidth();

        e.ctx.drawTextWithShadow(font, "Skull Client", 4, 4, 0xFF55FFFF);
        int ly = 16;
        if (coords.get()) {
            e.ctx.drawTextWithShadow(font, String.format("XYZ %.1f %.1f %.1f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, ly, 0xFFDDDDDD);
            ly += 10;
        }
        if (fps.get()) e.ctx.drawTextWithShadow(font, "FPS " + mc.getCurrentFps(), 4, ly, 0xFFDDDDDD);

        if (!list.get()) return;
        List<Module> active = ModuleManager.all().stream()
            .filter(Module::isEnabled).filter(m -> m != this)
            .sorted(Comparator.comparingInt((Module m) -> font.getWidth(label(m))).reversed())
            .toList();

        int y = 4;
        long t = System.currentTimeMillis();
        for (Module m : active) {
            String s = label(m);
            int x = width - font.getWidth(s) - 4;
            e.ctx.fill(x - 2, y - 1, width, y + 9, 0x90000000);
            int color = Color.HSBtoRGB(((y * 0.01f) + (t % 4000) / 4000f) % 1f, 0.6f, 1f);
            e.ctx.drawTextWithShadow(font, s, x, y, color);
            y += 10;
        }
    }

    private String label(Module m) {
        return m.hudSuffix().isEmpty() ? m.name : m.name + " \u00a77" + m.hudSuffix();
    }
}
