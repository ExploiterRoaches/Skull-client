package com.example.utilclient.core;

import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.ModeSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.stream.Collectors;

/** Chat commands, prefix ".". Handled locally; never sent to the server. */
public final class Commands {
    public static final String PREFIX = ".";
    private Commands() {}

    /** @return true if the message was a command (and must not be sent). */
    public static boolean handle(String message) {
        if (!message.startsWith(PREFIX) || message.startsWith("..")) return false;
        try {
            String[] a = message.substring(1).trim().split("\\s+");
            switch (a[0].toLowerCase()) {
                case "help", "h" -> help();
                case "modules", "m" -> say("Modules: " + ModuleManager.all().stream()
                        .map(m -> (m.isEnabled() ? "\u00a7a" : "\u00a77") + m.name).collect(Collectors.joining("\u00a7r, ")));
                case "toggle", "t" -> {
                    Module m = need(a, 1);
                    if (m != null) { m.toggle(); say(m.name + (m.isEnabled() ? " \u00a7aON" : " \u00a7cOFF")); }
                }
                case "bind" -> bind(a);
                case "set" -> set(a);
                case "settings" -> {
                    Module m = need(a, 1);
                    if (m != null) say(m.name + ": " + m.settings().stream()
                            .map(s -> s.name + "=" + s.get()).collect(Collectors.joining(", ")));
                }
                case "save" -> { Config.save(); say("Saved."); }
                default -> say("Unknown command. Try \u00a7b.help");
            }
        } catch (Throwable t) {
            say("\u00a7cCommand failed: " + t.getMessage());
        }
        return true;
    }

    private static void help() {
        say("\u00a7b.toggle <module>\u00a7r  \u00a7b.modules\u00a7r  \u00a7b.settings <module>");
        say("\u00a7b.set <module> <setting> <value>\u00a7r  \u00a7b.bind <module> <key|none>\u00a7r  \u00a7b.save");
        say("Right Shift opens the ClickGUI. Start a chat message with \"..\" to send a message that begins with a dot.");
    }

    private static void bind(String[] a) {
        Module m = need(a, 1);
        if (m == null) return;
        if (a.length < 3) { say("Usage: .bind <module> <key|none>"); return; }
        if (a[2].equalsIgnoreCase("none")) { m.key = -1; say(m.name + " unbound."); return; }
        int code = InputUtil.fromTranslationKey("key.keyboard." + a[2].toLowerCase()).getCode();
        m.key = code;
        say(m.name + " bound to " + a[2].toUpperCase() + ".");
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void set(String[] a) {
        Module m = need(a, 1);
        if (m == null) return;
        if (a.length < 4) { say("Usage: .set <module> <setting> <value>"); return; }
        for (Setting s : m.settings()) {
            if (!s.name.equalsIgnoreCase(a[2])) continue;
            if (s instanceof BoolSetting b) b.set(Boolean.parseBoolean(a[3]));
            else if (s instanceof NumberSetting n) n.set(Double.parseDouble(a[3]));
            else if (s instanceof ModeSetting ms) {
                String match = ms.modes.stream().filter(x -> x.equalsIgnoreCase(a[3])).findFirst().orElse(null);
                if (match == null) { say("Modes: " + ms.modes); return; }
                ms.set(match);
            } else { say("That setting can only be changed in the ClickGUI."); return; }
            say(m.name + "." + s.name + " = " + s.get());
            return;
        }
        say("No such setting. See \u00a7b.settings " + m.name);
    }

    private static Module need(String[] a, int i) {
        if (a.length <= i) { say("Missing module name."); return null; }
        Module m = ModuleManager.find(a[i]);
        if (m == null) say("No module named \"" + a[i] + "\". Try \u00a7b.modules");
        return m;
    }

    private static void say(String s) {
        var p = MinecraftClient.getInstance().player;
        if (p != null) p.sendMessage(Text.literal("\u00a73[Skull] \u00a7r" + s), false);
    }
}
