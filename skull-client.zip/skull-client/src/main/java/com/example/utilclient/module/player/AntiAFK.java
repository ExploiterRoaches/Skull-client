package com.example.utilclient.module.player;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import net.minecraft.util.Hand;

@ModuleInfo(name = "AntiAFK", category = Category.PLAYER, desc = "Small random actions so you don't get idle-kicked.")
public class AntiAFK extends Module {
    private final NumberSetting interval = add(new NumberSetting("Interval(s)", 20, 5, 120, 5));
    private int ticks;
    private int next = 400;

    @Subscribe
    private void onTick(TickEvent e) {
        if (++ticks < next) return;
        ticks = 0;
        next = (int) (interval.get() * 20 * (0.7 + Math.random() * 0.6));
        switch ((int) (Math.random() * 3)) {
            case 0 -> mc.player.swingHand(Hand.MAIN_HAND);
            case 1 -> { if (mc.player.isOnGround()) mc.player.jump(); }
            default -> mc.player.setYaw(mc.player.getYaw() + (float) ((Math.random() - 0.5) * 40));
        }
    }
}
