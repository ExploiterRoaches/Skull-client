package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Zoom", category = Category.RENDER, key = GLFW.GLFW_KEY_C, desc = "Narrows your field of view.")
public class Zoom extends Module {
    // Minecraft rejects FOV values below 30, so 30 is the strongest zoom.
    private final NumberSetting fov = add(new NumberSetting("FOV", 30, 30, 60, 5));
    private int original = -1;

    @Override protected void onEnable() { original = mc.options.getFov().getValue(); }

    @Override protected void onDisable() {
        if (original != -1 && mc.options != null) mc.options.getFov().setValue(original);
        original = -1;
    }

    @Subscribe
    private void onTick(TickEvent e) {
        int target = fov.i();
        if (mc.options.getFov().getValue() != target) mc.options.getFov().setValue(target);
    }
}
