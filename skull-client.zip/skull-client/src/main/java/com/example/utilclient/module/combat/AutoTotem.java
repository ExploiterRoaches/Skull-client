package com.example.utilclient.module.combat;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

@ModuleInfo(name = "AutoTotem", category = Category.COMBAT, desc = "Keeps a Totem of Undying in your offhand.")
public class AutoTotem extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay(ms)", 120, 0, 1000, 10));
    private final Stopwatch timer = new Stopwatch();

    @Subscribe
    private void onTick(TickEvent e) {
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) || !timer.passed(delay.i())) return;

        int syncId = mc.player.playerScreenHandler.syncId;
        for (int i = 9; i < 45; i++) {   // main inventory + hotbar in the player screen handler
            if (mc.player.playerScreenHandler.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                mc.interactionManager.clickSlot(syncId, i, 40, SlotActionType.SWAP, mc.player);  // 40 = offhand
                timer.reset();
                return;
            }
        }
    }
}
