# Scull Client (Fabric, Minecraft 1.21.1)

Modular client skeleton: Category > Module > Setting, annotation-based modules, reflection event bus.

## Build a .jar

1. Install JDK 21.
2. Open this folder in IntelliJ IDEA (it imports Gradle automatically), or from a terminal:
   ```
   gradle wrapper --gradle-version 8.10   # one time; needs Gradle installed (wrapper jar is not bundled)
   ./gradlew build                        # Windows: gradlew.bat build
   ```
3. The jar is `build/libs/scullclient-1.0.0.jar` (not the `-sources` one).
4. Install it in `.minecraft/mods` with **Fabric Loader 0.16.x** and **Fabric API 0.104.0+1.21.1** (or newer 1.21.1 build).
5. Dev client: `./gradlew runClient`.

## Use

- **Right Shift**: ClickGUI (left-click toggles a module, right-click expands its settings).
- Default keys: KillAura R, ESP J, XRay X, Fullbright B, Scaffold G, Sprint V, Fly F, Speed Z.
  Toggling by key shows ON/OFF above the hotbar.
- Settings and keybinds persist to `config/utilclient.json`.
- Tip: XRay + Fullbright together makes ores visible in dark caves.

## Stability design

- Modules are created only after the client has fully started.
- Every callback is wrapped; a module that throws is **switched off with a red chat message** instead of crashing the game.
- Mixins use `defaultRequire: 0` and `required: false`: if a target changed in your version, that one feature just does nothing (a warning appears in the log) instead of a launch crash.
- Only 3 mixins (XRay, ESP glow, Fullbright gamma). No packet/keyboard/world-render mixins.
- ESP restores GL state in a `finally` block.

## If something goes wrong

- Build error: the Yarn name changed in your version. Note the file/line, they are small fixes.
- Game crash or feature not working: send `.minecraft/logs/latest.log` (or the `crash-reports/` file). Lines starting with `[UtilClient]` name the module.

## Layout

```
core/     Module, ModuleInfo, ModuleManager, Category, Config
setting/  Bool / Number / Mode / BlockList settings
event/    EventBus + Tick / RenderWorld / RenderHud / Packet events
module/   combat, render, movement, world
mixin/    BlockMixin (XRay), EntityMixin (ESP glow), SimpleOptionMixin (Fullbright)
ui/       ClickGuiScreen
```

Adding a module: extend `Module`, annotate with `@ModuleInfo`, add it to `ModuleManager.init()`.

## Notes

- Source was syntax-checked but not compiled against Minecraft or run in-game by the author.
- Intended for singleplayer, your own server, or servers that allow it. Most public servers prohibit these features and will ban you.
