package com.example.utilclient.core;

import com.example.utilclient.event.EventBus;
import com.example.utilclient.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final Category category;
    public final String desc;
    public int key;

    private boolean enabled;
    private final List<Setting<?>> settings = new ArrayList<>();

    protected Module() {
        ModuleInfo info = getClass().getAnnotation(ModuleInfo.class);
        if (info == null) throw new IllegalStateException(getClass() + " is missing @ModuleInfo");
        name = info.name();
        category = info.category();
        key = info.key();
        desc = info.desc();
    }

    protected <S extends Setting<?>> S add(S setting) { settings.add(setting); return setting; }
    public List<Setting<?>> settings() { return settings; }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) { EventBus.register(this); onEnable(); }
            else       { EventBus.unregister(this); onDisable(); }
        } catch (Throwable t) {
            // Never let a module's enable/disable hook take the game down.
            t.printStackTrace();
            if (value) { enabled = false; EventBus.unregister(this); }
        }
    }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Extra text shown next to the name in the HUD list. */
    public String hudSuffix() { return ""; }
}
