package com.example.utilclient.util;

public class Stopwatch {
    private long last = System.currentTimeMillis();
    public boolean passed(long ms) { return System.currentTimeMillis() - last >= ms; }
    public void reset() { last = System.currentTimeMillis(); }
}
