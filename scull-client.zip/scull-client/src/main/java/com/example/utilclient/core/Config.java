package com.example.utilclient.core;

import com.example.utilclient.setting.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saves keybinds and settings to config/utilclient.json (enabled state is not restored). */
public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("utilclient.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {}

    public static void save() {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("key", m.key);
            JsonObject s = new JsonObject();
            for (Setting<?> st : m.settings()) s.add(st.name, st.toJson());
            o.add("settings", s);
            root.add(m.name, o);
        }
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(root)); }
        catch (IOException e) { e.printStackTrace(); }
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : ModuleManager.all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (!o.has("settings")) continue;
                JsonObject s = o.getAsJsonObject("settings");
                for (Setting<?> st : m.settings()) {
                    JsonElement el = s.get(st.name);
                    if (el != null) try { st.fromJson(el); } catch (RuntimeException ignored) {}
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
