package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.setting.BlockListSetting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "XRay", category = Category.RENDER, key = GLFW.GLFW_KEY_X,
            desc = "Hides every block that is not on the whitelist.")
public class XRay extends Module {
    public static XRay INSTANCE;

    private final BlockListSetting whitelist = add(new BlockListSetting("Blocks",
        Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
        Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE,
        Blocks.REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.EMERALD_ORE, Blocks.COPPER_ORE,
        Blocks.ANCIENT_DEBRIS, Blocks.NETHER_GOLD_ORE, Blocks.NETHER_QUARTZ_ORE,
        Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.SPAWNER,
        Blocks.NETHER_PORTAL, Blocks.END_PORTAL_FRAME, Blocks.LAVA, Blocks.WATER));

    public XRay() { INSTANCE = this; }

    public boolean visible(Block b) { return whitelist.contains(b); }

    @Override protected void onEnable()  { if (mc.worldRenderer != null) mc.worldRenderer.reload(); }
    @Override protected void onDisable() { if (mc.worldRenderer != null) mc.worldRenderer.reload(); }
}
