package com.example.utilclient.event;

import net.minecraft.client.util.math.MatrixStack;

public class RenderWorldEvent extends Event {
    public final MatrixStack matrices;
    public final float tickDelta;
    public RenderWorldEvent(MatrixStack matrices, float tickDelta) { this.matrices = matrices; this.tickDelta = tickDelta; }
}
