package com.example.utilclient.event;

public abstract class Event {
    private boolean cancelled;
    public boolean isCancelled() { return cancelled; }
    public void cancel() { cancelled = true; }
}
