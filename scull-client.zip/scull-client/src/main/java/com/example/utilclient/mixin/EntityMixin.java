package com.example.utilclient.mixin;

import com.example.utilclient.module.render.ESP;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void utilclient$glow(CallbackInfoReturnable<Boolean> cir) {
        ESP esp = ESP.INSTANCE;
        if (esp != null && esp.isEnabled() && esp.shouldGlow((Entity) (Object) this)) cir.setReturnValue(true);
    }
}
