package com.example.utilclient.module.combat;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.ModeSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.RotationUtil;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.stream.StreamSupport;

@ModuleInfo(name = "KillAura", category = Category.COMBAT, key = GLFW.GLFW_KEY_R,
            desc = "Attacks nearby targets. TriggerBot mode only hits what the crosshair is on.")
public class KillAura extends Module {
    private final NumberSetting range    = add(new NumberSetting("Range", 3.5, 2, 6, 0.1));
    private final NumberSetting fov      = add(new NumberSetting("FOV", 180, 30, 360, 5));
    private final ModeSetting priority   = add(new ModeSetting("Priority", "Distance", "Distance", "Health", "Angle"));
    private final ModeSetting timing     = add(new ModeSetting("Timing", "Cooldown", "Cooldown", "CPS"));
    private final NumberSetting minCps   = add(new NumberSetting("MinCPS", 8, 1, 20, 1));
    private final NumberSetting maxCps   = add(new NumberSetting("MaxCPS", 12, 1, 20, 1));
    private final NumberSetting cooldown = add(new NumberSetting("Cooldown%", 0.92, 0.5, 1.0, 0.01));
    private final NumberSetting turn     = add(new NumberSetting("TurnSpeed", 40, 5, 180, 5));
    private final BoolSetting players    = add(new BoolSetting("Players", true));
    private final BoolSetting mobs       = add(new BoolSetting("Mobs", false));
    private final BoolSetting trigger    = add(new BoolSetting("TriggerBot", false));
    private final BoolSetting los        = add(new BoolSetting("RequireLOS", true));

    private final Stopwatch cpsTimer = new Stopwatch();
    private long nextDelay = 100;
    private float[] rot;
    private LivingEntity target;

    @Override protected void onEnable() {
        if (mc.player != null) rot = new float[] { mc.player.getYaw(), mc.player.getPitch() };
    }

    @Subscribe
    private void onTick(TickEvent e) {
        if (mc.currentScreen != null || !mc.player.isAlive() || mc.player.isSpectator()) return;
        if (rot == null) rot = new float[] { mc.player.getYaw(), mc.player.getPitch() };

        if (trigger.get()) {
            target = (mc.crosshairTarget instanceof EntityHitResult hit
                      && hit.getEntity() instanceof LivingEntity le && valid(le)) ? le : null;
        } else {
            target = pickTarget();
        }
        if (target == null) { rot[0] = mc.player.getYaw(); rot[1] = mc.player.getPitch(); return; }

        if (!trigger.get()) {
            float[] goal = RotationUtil.toTarget(mc.player.getEyePos(), target.getBoundingBox().getCenter());
            rot = RotationUtil.smooth(new float[] { mc.player.getYaw(), mc.player.getPitch() }, goal, turn.f(), 1.5f);
            rot[0] = RotationUtil.gcdFix(rot[0], mc.player.getYaw());
            mc.player.setYaw(rot[0]);
            mc.player.setPitch(rot[1]);
        }

        if (ready()) {
            mc.interactionManager.attackEntity(mc.player, target);   // attack packet
            mc.player.swingHand(Hand.MAIN_HAND);                      // swing packet
        }
    }

    private boolean ready() {
        if (timing.is("Cooldown")) return mc.player.getAttackCooldownProgress(0.5f) >= cooldown.f();
        if (!cpsTimer.passed(nextDelay)) return false;
        cpsTimer.reset();
        double cps = minCps.get() + Math.random() * Math.max(0, maxCps.get() - minCps.get());
        nextDelay = (long) (1000.0 / Math.max(1, cps));
        return true;
    }

    private boolean valid(LivingEntity en) {
        if (en == mc.player || !en.isAlive()) return false;
        if (mc.player.distanceTo(en) > range.get()) return false;
        boolean typeOk = (en instanceof PlayerEntity && players.get()) || (en instanceof HostileEntity && mobs.get());
        if (!typeOk) return false;
        if (!RotationUtil.inFov(en, fov.f())) return false;
        return !los.get() || mc.player.canSee(en);
    }

    private LivingEntity pickTarget() {
        Comparator<LivingEntity> cmp;
        switch (priority.get()) {
            case "Health" -> cmp = Comparator.comparingDouble((LivingEntity en) -> en.getHealth());
            case "Angle"  -> cmp = Comparator.comparingDouble((LivingEntity en) -> Math.abs(MathHelper.wrapDegrees(
                    RotationUtil.toTarget(mc.player.getEyePos(), en.getEyePos())[0] - mc.player.getYaw())));
            default       -> cmp = Comparator.comparingDouble((LivingEntity en) -> mc.player.distanceTo(en));
        }
        return StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                .filter(en -> en instanceof LivingEntity)
                .map(en -> (LivingEntity) en)
                .filter(this::valid)
                .min(cmp).orElse(null);
    }

    @Override public String hudSuffix() { return trigger.get() ? "Trigger" : timing.get(); }
}
