package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.ModeSetting;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Fullbright", category = Category.RENDER, key = GLFW.GLFW_KEY_B, desc = "Clear vision in the dark.")
public class Fullbright extends Module {
    public static Fullbright INSTANCE;

    private final ModeSetting mode = add(new ModeSetting("Mode", "Gamma", "Gamma", "NightVision"));

    public Fullbright() { INSTANCE = this; }

    public boolean gammaActive() { return isEnabled() && mode.is("Gamma"); }

    @Subscribe
    private void onTick(TickEvent e) {
        if (mode.is("NightVision"))   // client-side only
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 420, 0, false, false));
    }

    @Override protected void onDisable() {
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }

    @Override public String hudSuffix() { return mode.get(); }
}
