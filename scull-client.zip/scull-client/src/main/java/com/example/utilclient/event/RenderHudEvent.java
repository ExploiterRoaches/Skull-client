package com.example.utilclient.event;

import net.minecraft.client.gui.DrawContext;

public class RenderHudEvent extends Event {
    public final DrawContext ctx;
    public RenderHudEvent(DrawContext ctx) { this.ctx = ctx; }
}
