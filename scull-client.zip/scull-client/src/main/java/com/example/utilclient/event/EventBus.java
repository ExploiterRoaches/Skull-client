package com.example.utilclient.event;

import com.example.utilclient.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Tiny reflection-based bus. Modules register on enable and unregister on disable. */
public final class EventBus {
    private record Handler(Object owner, Method method) {}
    private static final Map<Class<?>, List<Handler>> HANDLERS = new ConcurrentHashMap<>();

    private EventBus() {}

    public static void register(Object o) {
        for (Method m : o.getClass().getDeclaredMethods()) {
            if (!m.isAnnotationPresent(Subscribe.class) || m.getParameterCount() != 1) continue;
            m.setAccessible(true);
            HANDLERS.computeIfAbsent(m.getParameterTypes()[0], k -> new CopyOnWriteArrayList<>())
                    .add(new Handler(o, m));
        }
    }

    public static void unregister(Object o) {
        HANDLERS.values().forEach(l -> l.removeIf(h -> h.owner == o));
    }

    public static <E extends Event> E post(E event) {
        List<Handler> list = HANDLERS.get(event.getClass());
        if (list == null) return event;
        for (Handler h : list) {
            try {
                h.method.invoke(h.owner, event);
            } catch (Throwable t) {
                fail(h.owner, t instanceof InvocationTargetException ite && ite.getCause() != null ? ite.getCause() : t);
            }
        }
        return event;
    }

    /** Switch the offending module off so one bug can never crash the game or spam the log every tick. */
    private static void fail(Object owner, Throwable t) {
        System.err.println("[UtilClient] Error in " + owner.getClass().getSimpleName() + ", disabling it:");
        t.printStackTrace();
        if (owner instanceof Module m) {
            try { m.setEnabled(false); } catch (Throwable ignored) {}
            try {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null)
                    mc.player.sendMessage(Text.literal("\u00a7c[UtilClient] " + m.name + " crashed and was disabled: " + t), false);
            } catch (Throwable ignored) {}
        }
    }
}
