package com.example.utilclient.module.movement;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.ModeSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.MoveUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Fly", category = Category.MOVEMENT, key = GLFW.GLFW_KEY_F, desc = "Creative-style or velocity flight.")
public class Fly extends Module {
    private final ModeSetting mode      = add(new ModeSetting("Mode", "Creative", "Creative", "Velocity"));
    private final NumberSetting speed   = add(new NumberSetting("Speed", 0.6, 0.05, 3.0, 0.05));
    private final BoolSetting antiKick  = add(new BoolSetting("AntiKick", true));
    private int ticks;

    @Override protected void onDisable() {
        if (mc.player == null) return;
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().flying = false;
            mc.player.getAbilities().allowFlying = false;
        }
        mc.player.getAbilities().setFlySpeed(0.05f);
    }

    @Subscribe
    private void onTick(TickEvent e) {
        if (mode.is("Creative")) {
            mc.player.getAbilities().allowFlying = true;
            mc.player.getAbilities().flying = true;
            mc.player.getAbilities().setFlySpeed(speed.f() / 10f);
            return;
        }
        double y = mc.options.jumpKey.isPressed() ? speed.get() : mc.options.sneakKey.isPressed() ? -speed.get() : 0;
        if (antiKick.get() && y == 0 && ++ticks % 20 == 0) y = -0.04;   // small periodic dip
        Vec3d h = MoveUtil.horizontal(speed.get());
        mc.player.setVelocity(h.x, y, h.z);
    }

    @Override public String hudSuffix() { return mode.get(); }
}
