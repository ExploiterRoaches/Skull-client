package com.example.utilclient.core;

public enum Category { COMBAT, RENDER, MOVEMENT, WORLD }
