package com.example.utilclient.ui;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Config;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleManager;
import com.example.utilclient.setting.BlockListSetting;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.ModeSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * One column per category. Left-click a module to toggle it, right-click to expand its settings.
 * Settings: bool = click toggles, mode = click cycles, number = left +step / right -step.
 */
public class ClickGuiScreen extends Screen {
    private static final int COL_W = 110, ROW_H = 14, TOP = 24, LEFT = 20, GAP = 8;
    private Module expanded;

    public ClickGuiScreen() { super(Text.literal("ClickGUI")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { Config.save(); super.close(); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        layout(ctx, mouseX, mouseY, -1);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        layout(null, (int) mouseX, (int) mouseY, button);
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /** ctx != null: draw. button >= 0: handle a click at (mx, my). Same walk for both keeps hitboxes in sync. */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void layout(DrawContext ctx, int mx, int my, int button) {
        int i = 0;
        for (Category cat : Category.values()) {
            int x = LEFT + i++ * (COL_W + GAP);
            int y = TOP;
            if (ctx != null) {
                ctx.fill(x, y, x + COL_W, y + ROW_H, 0xFF1E5AA8);
                ctx.drawTextWithShadow(textRenderer, cat.name(), x + 4, y + 3, 0xFFFFFFFF);
            }
            y += ROW_H;

            for (Module m : ModuleManager.byCategory(cat)) {
                boolean hover = mx >= x && mx < x + COL_W && my >= y && my < y + ROW_H;
                if (ctx != null) {
                    ctx.fill(x, y, x + COL_W, y + ROW_H, hover ? 0xC0303030 : 0xC0101010);
                    ctx.drawTextWithShadow(textRenderer, m.name, x + 4, y + 3, m.isEnabled() ? 0xFF55FF55 : 0xFFBBBBBB);
                }
                if (button >= 0 && hover) {
                    if (button == 0) m.toggle();
                    else if (button == 1) expanded = (expanded == m) ? null : m;
                }
                y += ROW_H;

                if (expanded != m) continue;
                for (Setting<?> s : m.settings()) {
                    boolean sh = mx >= x && mx < x + COL_W && my >= y && my < y + ROW_H;
                    if (ctx != null) {
                        ctx.fill(x + 4, y, x + COL_W, y + ROW_H, sh ? 0xC0404040 : 0xC0202020);
                        ctx.drawTextWithShadow(textRenderer, s.name + ": " + display(s), x + 8, y + 3, 0xFFDDDDDD);
                    }
                    if (button >= 0 && sh) {
                        if (s instanceof BoolSetting b) b.toggle();
                        else if (s instanceof ModeSetting ms) ms.cycle();
                        else if (s instanceof NumberSetting ns)
                            ns.set(ns.get() + (button == 0 ? ns.step : -ns.step));
                    }
                    y += ROW_H;
                }
            }
        }
    }

    private String display(Setting<?> s) {
        if (s instanceof NumberSetting n) return String.format("%.2f", n.get());
        if (s instanceof BlockListSetting b) return b.get().size() + " blocks";
        return String.valueOf(s.get());
    }
}
