package com.example.utilclient.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class RenderUtil {
    private RenderUtil() {}

    public static void begin() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();          // draw through walls
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.lineWidth(1.5f);
    }

    public static void end() {
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    /** Box is expected in camera-relative coordinates. */
    public static void drawBox(MatrixStack ms, Box b, int argb) {
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        float x1 = (float) b.minX, y1 = (float) b.minY, z1 = (float) b.minZ;
        float x2 = (float) b.maxX, y2 = (float) b.maxY, z2 = (float) b.maxZ;
        // bottom
        line(bb, m, x1, y1, z1, x2, y1, z1, argb); line(bb, m, x2, y1, z1, x2, y1, z2, argb);
        line(bb, m, x2, y1, z2, x1, y1, z2, argb); line(bb, m, x1, y1, z2, x1, y1, z1, argb);
        // top
        line(bb, m, x1, y2, z1, x2, y2, z1, argb); line(bb, m, x2, y2, z1, x2, y2, z2, argb);
        line(bb, m, x2, y2, z2, x1, y2, z2, argb); line(bb, m, x1, y2, z2, x1, y2, z1, argb);
        // verticals
        line(bb, m, x1, y1, z1, x1, y2, z1, argb); line(bb, m, x2, y1, z1, x2, y2, z1, argb);
        line(bb, m, x2, y1, z2, x2, y2, z2, argb); line(bb, m, x1, y1, z2, x1, y2, z2, argb);
        BufferRenderer.drawWithGlobalProgram(bb.end());
    }

    public static void drawLine(MatrixStack ms, Vec3d a, Vec3d b, int argb) {
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        line(bb, m, (float) a.x, (float) a.y, (float) a.z, (float) b.x, (float) b.y, (float) b.z, argb);
        BufferRenderer.drawWithGlobalProgram(bb.end());
    }

    private static void line(BufferBuilder bb, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int c) {
        bb.vertex(m, x1, y1, z1).color(c);
        bb.vertex(m, x2, y2, z2).color(c);
    }
}
