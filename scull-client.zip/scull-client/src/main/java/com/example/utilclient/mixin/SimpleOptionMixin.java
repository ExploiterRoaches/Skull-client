package com.example.utilclient.mixin;

import com.example.utilclient.module.render.Fullbright;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SimpleOption.class)
public class SimpleOptionMixin<T> {
    @SuppressWarnings("unchecked")
    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true)
    private void utilclient$gamma(CallbackInfoReturnable<T> cir) {
        Fullbright fb = Fullbright.INSTANCE;
        if (fb == null || !fb.gammaActive()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null && (Object) this == mc.options.getGamma())
            cir.setReturnValue((T) (Double) 16.0);
    }
}
