package com.example.utilclient.event;

public class TickEvent extends Event {}
