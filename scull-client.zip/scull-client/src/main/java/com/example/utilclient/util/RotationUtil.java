package com.example.utilclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class RotationUtil {
    private RotationUtil() {}

    /** @return {yaw, pitch} from eye to target. */
    public static float[] toTarget(Vec3d eye, Vec3d target) {
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return new float[] {
            (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f,
            (float) -Math.toDegrees(Math.atan2(dy, h))
        };
    }

    /** Step from cur toward goal by at most maxStep degrees per call, plus tiny jitter. */
    public static float[] smooth(float[] cur, float[] goal, float maxStep, float jitter) {
        float dYaw = MathHelper.wrapDegrees(goal[0] - cur[0]);
        float dPitch = goal[1] - cur[1];
        float yaw = cur[0] + MathHelper.clamp(dYaw, -maxStep, maxStep) + (float) ((Math.random() - 0.5) * jitter);
        float pitch = cur[1] + MathHelper.clamp(dPitch, -maxStep, maxStep) + (float) ((Math.random() - 0.5) * jitter);
        return new float[] { yaw, MathHelper.clamp(pitch, -90f, 90f) };
    }

    /** Snap a rotation to the increments real mouse input would produce at the current sensitivity. */
    public static float gcdFix(float rot, float prev) {
        double s = MinecraftClient.getInstance().options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        float step = (float) (s * s * s * 8.0 * 0.15);
        return prev + Math.round((rot - prev) / step) * step;
    }

    public static boolean inFov(Entity e, float fov) {
        var p = MinecraftClient.getInstance().player;
        float[] r = toTarget(p.getEyePos(), e.getBoundingBox().getCenter());
        return Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw())) <= fov / 2f;
    }
}
