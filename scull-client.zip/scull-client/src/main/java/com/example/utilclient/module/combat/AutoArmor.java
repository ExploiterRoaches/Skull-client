package com.example.utilclient.module.combat;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.slot.SlotActionType;

@ModuleInfo(name = "AutoArmor", category = Category.COMBAT, desc = "Equips the best armor from your inventory.")
public class AutoArmor extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay(ms)", 150, 0, 1000, 10));
    private final BoolSetting invOnly = add(new BoolSetting("InventoryOnly", false));
    private final Stopwatch timer = new Stopwatch();

    private static final EquipmentSlot[] ARMOR = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    @Subscribe
    private void onTick(TickEvent e) {
        if (!timer.passed(delay.i())) return;
        if (invOnly.get() && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;

        int syncId = mc.player.playerScreenHandler.syncId;
        for (EquipmentSlot slot : ARMOR) {
            ItemStack worn = mc.player.getEquippedStack(slot);
            double best = score(worn);
            int bestSlot = -1;
            for (int i = 9; i < 45; i++) {
                ItemStack s = mc.player.playerScreenHandler.getSlot(i).getStack();
                if (s.getItem() instanceof ArmorItem a && a.getSlotType() == slot && score(s) > best) {
                    best = score(s);
                    bestSlot = i;
                }
            }
            if (bestSlot == -1) continue;

            int armorSlotId = 8 - slot.getEntitySlotId();       // 5..8 in the player screen handler
            if (!worn.isEmpty()) {
                mc.interactionManager.clickSlot(syncId, armorSlotId, 0, SlotActionType.QUICK_MOVE, mc.player); // unequip first
            } else {
                mc.interactionManager.clickSlot(syncId, bestSlot, 0, SlotActionType.QUICK_MOVE, mc.player);   // equip
            }
            timer.reset();
            return;   // one action per delay window
        }
    }

    private double score(ItemStack s) {
        if (!(s.getItem() instanceof ArmorItem a)) return -1;
        return a.getProtection() + a.getToughness() * 0.5 + protectionLevel(s) * 1.25;
    }

    private int protectionLevel(ItemStack s) {
        var reg = mc.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
        return reg.getEntry(Enchantments.PROTECTION).map(en -> EnchantmentHelper.getLevel(en, s)).orElse(0);
    }
}
