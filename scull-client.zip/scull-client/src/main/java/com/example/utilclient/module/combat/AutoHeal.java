package com.example.utilclient.module.combat;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@ModuleInfo(name = "AutoHeal", category = Category.COMBAT, desc = "AutoSoup equivalent: eats healing items when low.")
public class AutoHeal extends Module {
    private final NumberSetting health = add(new NumberSetting("HealthBelow", 10, 1, 19, 1));
    private final NumberSetting delay  = add(new NumberSetting("Delay(ms)", 300, 50, 2000, 10));
    private final Stopwatch timer = new Stopwatch();

    private boolean healing;
    private int prevSlot = -1;
    private int ticksHealing;

    @Override protected void onDisable() { finish(); }

    @Subscribe
    private void onTick(TickEvent e) {
        if (healing) {
            ticksHealing++;
            boolean eating = mc.player.isUsingItem();
            // Hold the use key: vanilla stops using an item the tick after the key is released.
            if (eating && ticksHealing < 80) { mc.options.useKey.setPressed(true); return; }
            if (ticksHealing < 4) { mc.options.useKey.setPressed(true); return; }   // give it a moment to start
            finish();
            timer.reset();
            return;
        }

        if (mc.currentScreen != null || mc.player.getHealth() > health.f() || !timer.passed(delay.i())) return;

        for (int i = 0; i < 9; i++) {
            if (!isHealItem(mc.player.getInventory().getStack(i))) continue;
            prevSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = i;
            mc.options.useKey.setPressed(true);
            healing = true;
            ticksHealing = 0;
            return;
        }
    }

    private void finish() {
        if (mc.options != null) mc.options.useKey.setPressed(false);
        if (mc.player != null && prevSlot != -1) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
        healing = false;
        ticksHealing = 0;
    }

    private boolean isHealItem(ItemStack s) {
        return s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.MUSHROOM_STEW)
            || s.isOf(Items.RABBIT_STEW) || s.isOf(Items.BEETROOT_SOUP);
    }
}
