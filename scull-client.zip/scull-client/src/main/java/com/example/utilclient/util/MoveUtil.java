package com.example.utilclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public final class MoveUtil {
    private MoveUtil() {}

    public static boolean isMoving() {
        var in = MinecraftClient.getInstance().player.input;
        return in.movementForward != 0 || in.movementSideways != 0;
    }

    /** Horizontal velocity vector of the given speed in the player's input direction. */
    public static Vec3d horizontal(double speed) {
        var p = MinecraftClient.getInstance().player;
        double f = p.input.movementForward, s = p.input.movementSideways;
        if (f == 0 && s == 0) return Vec3d.ZERO;
        double len = Math.hypot(f, s);
        f /= len; s /= len;
        double yaw = Math.toRadians(p.getYaw());
        return new Vec3d(
            (-Math.sin(yaw) * f + Math.cos(yaw) * s) * speed, 0,
            ( Math.cos(yaw) * f + Math.sin(yaw) * s) * speed);
    }
}
