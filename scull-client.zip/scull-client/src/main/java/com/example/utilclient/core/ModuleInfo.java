package com.example.utilclient.core;

import org.lwjgl.glfw.GLFW;
import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ModuleInfo {
    String name();
    Category category();
    int key() default GLFW.GLFW_KEY_UNKNOWN;
    String desc() default "";
}
