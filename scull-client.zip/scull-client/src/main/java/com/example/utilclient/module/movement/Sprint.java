package com.example.utilclient.module.movement;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Sprint", category = Category.MOVEMENT, key = GLFW.GLFW_KEY_V, desc = "Automatically sprints.")
public class Sprint extends Module {
    private final BoolSetting omni = add(new BoolSetting("Omni", false));

    @Subscribe
    private void onTick(TickEvent e) {
        var in = mc.player.input;
        boolean moving = omni.get() ? (in.movementForward != 0 || in.movementSideways != 0) : in.movementForward > 0;
        if (moving && !mc.player.horizontalCollision && !mc.player.isSneaking()
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
