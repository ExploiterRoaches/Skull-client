package com.example.utilclient.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Editable block whitelist (used by X-Ray). Serialized as registry IDs. */
public class BlockListSetting extends Setting<Set<Block>> {
    public BlockListSetting(String name, Block... defaults) {
        super(name, new HashSet<>(Arrays.asList(defaults)));
    }
    public boolean contains(Block b) { return value.contains(b); }
    public void toggle(Block b) { if (!value.remove(b)) value.add(b); }

    @Override public JsonElement toJson() {
        JsonArray arr = new JsonArray();
        for (Block b : value) arr.add(new JsonPrimitive(Registries.BLOCK.getId(b).toString()));
        return arr;
    }
    @Override public void fromJson(JsonElement e) {
        Set<Block> next = new HashSet<>();
        for (JsonElement el : e.getAsJsonArray()) {
            Identifier id = Identifier.tryParse(el.getAsString());
            if (id != null && Registries.BLOCK.containsId(id)) next.add(Registries.BLOCK.get(id));
        }
        value = next;
    }
}
