# UtilClient (Fabric, Minecraft 1.21.1)

Modular client skeleton: Category > Module > Setting, annotation-based modules, reflection event bus.

## Build a .jar

1. Install JDK 21.
2. Open this folder in IntelliJ IDEA (it imports Gradle automatically), or from a terminal:
   ```
   gradle wrapper --gradle-version 8.10   # one time; needs Gradle installed. Wrapper jar is not bundled.
   ./gradlew build                        # Windows: gradlew.bat build
   ```
3. The jar is at `build/libs/utilclient-1.0.0.jar`. Drop it into `.minecraft/mods` with Fabric Loader 0.16.x and Fabric API 0.105.0+1.21.1.
4. To test in a dev client: `./gradlew runClient`.

## Use

- **Right Shift**: ClickGUI (left-click toggles a module, right-click expands its settings).
- Keybinds: KillAura R, ESP J, XRay X, Fullbright B, Scaffold G, Sprint V, Fly F, Speed Z.
- Settings and keybinds persist to `config/utilclient.json`.

## Layout

```
core/     Module, ModuleInfo, ModuleManager, Category, Config
setting/  Bool / Number / Mode / BlockList settings
event/    EventBus + Tick / RenderWorld / RenderHud / Packet events
module/   combat, render, movement, world
mixin/    BlockMixin (XRay), EntityMixin (ESP glow), SimpleOptionMixin (Fullbright), ClientConnectionMixin (packets)
ui/       ClickGuiScreen
```

## Notes

- Not compiled or tested by the author. Yarn method names drift between Minecraft versions, so expect small fixes if you change `minecraft_version`. Mixin injections use `defaultRequire: 1`; if the game crashes on launch with a mixin error, the target signature changed in your version.
- Adding a module: create a class extending `Module` with `@ModuleInfo`, add it to the list in `ModuleManager.init()`.
- Intended for singleplayer, your own server, or servers that allow it. Most public servers prohibit these features and will ban you.
