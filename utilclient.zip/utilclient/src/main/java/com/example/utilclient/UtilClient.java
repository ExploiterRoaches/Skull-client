package com.example.utilclient;

import com.example.utilclient.core.Config;
import com.example.utilclient.core.ModuleManager;
import com.example.utilclient.event.EventBus;
import com.example.utilclient.event.RenderHudEvent;
import com.example.utilclient.event.RenderWorldEvent;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.module.render.HUD;
import com.example.utilclient.ui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class UtilClient implements ClientModInitializer {
    private static final int GUI_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private boolean guiKeyDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();
        ModuleManager.get(HUD.class).setEnabled(true);

        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            ModuleManager.pollKeys(mc);

            boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GUI_KEY);
            if (down && !guiKeyDown && mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            guiKeyDown = down;

            EventBus.post(new TickEvent());
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> EventBus.post(new RenderHudEvent(ctx)));

        WorldRenderEvents.LAST.register(ctx -> {
            if (ctx.matrixStack() == null) return;
            EventBus.post(new RenderWorldEvent(ctx.matrixStack(), ctx.tickCounter().getTickDelta(false)));
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());
    }
}
