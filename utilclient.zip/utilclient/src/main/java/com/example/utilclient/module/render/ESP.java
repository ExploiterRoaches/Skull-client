package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.RenderWorldEvent;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.ModeSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "ESP", category = Category.RENDER, key = GLFW.GLFW_KEY_J, desc = "Boxes, glow outlines and tracers.")
public class ESP extends Module {
    public static ESP INSTANCE;

    private final ModeSetting mode    = add(new ModeSetting("Mode", "Box", "Box", "Outline"));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", true));
    private final NumberSetting range = add(new NumberSetting("Range", 64, 8, 256, 4));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs    = add(new BoolSetting("Mobs", true));

    public ESP() { INSTANCE = this; }

    private boolean isTarget(Entity en) {
        if (en == mc.player || mc.player.distanceTo(en) > range.get()) return false;
        return (en instanceof PlayerEntity && players.get()) || (en instanceof MobEntity && mobs.get());
    }

    /** Used by EntityMixin to force the vanilla glow outline. */
    public boolean shouldGlow(Entity en) {
        return mode.is("Outline") && mc.player != null && isTarget(en);
    }

    @Subscribe
    private void onRender(RenderWorldEvent e) {
        var camera = mc.gameRenderer.getCamera();
        Vec3d cam = camera.getPos();
        Vec3d lookFromCamera = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());   // crosshair origin for tracers

        RenderUtil.begin();
        for (Entity en : mc.world.getEntities()) {
            if (!isTarget(en)) continue;

            double x = MathHelper.lerp(e.tickDelta, en.prevX, en.getX()) - cam.x;
            double y = MathHelper.lerp(e.tickDelta, en.prevY, en.getY()) - cam.y;
            double z = MathHelper.lerp(e.tickDelta, en.prevZ, en.getZ()) - cam.z;
            int color = en instanceof PlayerEntity ? 0xFFFF4040 : 0xFF40FF40;

            if (mode.is("Box")) {
                Box local = en.getBoundingBox().offset(-en.getX(), -en.getY(), -en.getZ()).offset(x, y, z);
                RenderUtil.drawBox(e.matrices, local, color);
            }
            if (tracers.get()) {
                RenderUtil.drawLine(e.matrices, lookFromCamera, new Vec3d(x, y + en.getHeight() / 2, z), color);
            }
        }
        RenderUtil.end();
    }

    @Override public String hudSuffix() { return mode.get(); }
}
