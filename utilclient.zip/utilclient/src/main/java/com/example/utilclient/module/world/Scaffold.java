package com.example.utilclient.module.world;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.RotationUtil;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Scaffold", category = Category.WORLD, key = GLFW.GLFW_KEY_G, desc = "Places blocks under your feet.")
public class Scaffold extends Module {
    private final NumberSetting minDelay  = add(new NumberSetting("MinDelay", 50, 0, 500, 10));
    private final NumberSetting maxDelay  = add(new NumberSetting("MaxDelay", 110, 0, 500, 10));
    private final NumberSetting turn      = add(new NumberSetting("TurnSpeed", 60, 10, 180, 5));
    private final BoolSetting edgeOnly    = add(new BoolSetting("EdgeOnly", true));
    private final BoolSetting autoSwitch  = add(new BoolSetting("AutoSwitch", true));

    private final Stopwatch timer = new Stopwatch();
    private long delay = 80;
    private float[] rot;
    private int prevSlot = -1;

    @Override protected void onEnable() {
        if (mc.player == null) return;
        rot = new float[] { mc.player.getYaw(), mc.player.getPitch() };
        prevSlot = mc.player.getInventory().selectedSlot;
    }

    @Override protected void onDisable() {
        if (mc.player != null && prevSlot != -1) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    @Subscribe
    private void onTick(TickEvent e) {
        if (rot == null) rot = new float[] { mc.player.getYaw(), mc.player.getPitch() };
        if (edgeOnly.get() && !atEdge()) return;

        BlockPos below = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() - 1, mc.player.getZ());
        if (!mc.world.getBlockState(below).isReplaceable()) return;

        int slot = findBlockSlot();
        if (slot == -1) return;
        if (autoSwitch.get()) mc.player.getInventory().selectedSlot = slot;

        // Find a solid neighbour and the face we need to click on it.
        BlockPos neighbour = null;
        Direction face = null;
        for (Direction d : Direction.values()) {
            BlockPos n = below.offset(d);
            if (!mc.world.getBlockState(n).isReplaceable()) { neighbour = n; face = d.getOpposite(); break; }
        }
        if (neighbour == null) return;

        // 1) rotate toward the centre of that face (smoothed, GCD-snapped) and tell the server
        Vec3d hitVec = Vec3d.ofCenter(neighbour).add(Vec3d.of(face.getVector()).multiply(0.5));
        float[] goal = RotationUtil.toTarget(mc.player.getEyePos(), hitVec);
        rot = RotationUtil.smooth(rot, goal, turn.f(), 1f);
        rot[0] = RotationUtil.gcdFix(rot[0], mc.player.getYaw());
        mc.player.networkHandler.sendPacket(
            new PlayerMoveC2SPacket.LookAndOnGround(rot[0], rot[1], mc.player.isOnGround()));

        // 2) place only once the look is close enough and the delay has elapsed
        float diff = Math.abs(MathHelper.wrapDegrees(rot[0] - goal[0])) + Math.abs(rot[1] - goal[1]);
        if (diff > 12f || !timer.passed(delay)) return;

        BlockHitResult hit = new BlockHitResult(hitVec, face, neighbour, false);
        if (mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit).isAccepted())
            mc.player.swingHand(Hand.MAIN_HAND);

        timer.reset();
        delay = (long) (minDelay.get() + Math.random() * Math.max(0, maxDelay.get() - minDelay.get()));
    }

    /** Edge: the player's box, shifted along motion and slightly down, touches nothing solid. */
    private boolean atEdge() {
        Vec3d v = mc.player.getVelocity();
        Box probe = mc.player.getBoundingBox().offset(v.x * 2, -0.5, v.z * 2);
        return mc.world.isSpaceEmpty(mc.player, probe);
    }

    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.getItem() instanceof BlockItem bi
                    && bi.getBlock().getDefaultState().isFullCube(mc.world, BlockPos.ORIGIN)
                    && !(bi.getBlock() instanceof FallingBlock)
                    && !(bi.getBlock() instanceof BlockWithEntity)) return i;
        }
        return -1;
    }
}
