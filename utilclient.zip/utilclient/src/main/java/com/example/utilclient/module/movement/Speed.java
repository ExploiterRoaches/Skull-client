package com.example.utilclient.module.movement;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.BoolSetting;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.MoveUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(name = "Speed", category = Category.MOVEMENT, key = GLFW.GLFW_KEY_Z, desc = "Scales horizontal velocity.")
public class Speed extends Module {
    private final NumberSetting mult      = add(new NumberSetting("Multiplier", 1.15, 1.0, 3.0, 0.05));
    private final BoolSetting groundOnly  = add(new BoolSetting("GroundOnly", true));
    private final BoolSetting autoJump    = add(new BoolSetting("AutoJump", false));

    private static final double BASE = 0.2873;   // vanilla sprint-ish ground speed, blocks/tick
    private static final double CAP  = 0.9;      // hard ceiling

    @Subscribe
    private void onTick(TickEvent e) {
        if (!MoveUtil.isMoving()) return;
        if (groundOnly.get() && !mc.player.isOnGround()) return;
        if (autoJump.get() && mc.player.isOnGround()) mc.player.jump();

        Vec3d v = mc.player.getVelocity();
        double current = Math.hypot(v.x, v.z);
        double target = Math.min(Math.max(current, BASE) * mult.get(), CAP);
        Vec3d h = MoveUtil.horizontal(target);
        mc.player.setVelocity(h.x, v.y, h.z);
    }

    @Override public String hudSuffix() { return String.format("%.2fx", mult.get()); }
}
