package com.example.utilclient.event;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Tiny reflection-based bus. Modules register on enable and unregister on disable. */
public final class EventBus {
    private record Handler(Object owner, Method method) {}
    private static final Map<Class<?>, List<Handler>> HANDLERS = new ConcurrentHashMap<>();

    private EventBus() {}

    public static void register(Object o) {
        for (Method m : o.getClass().getDeclaredMethods()) {
            if (!m.isAnnotationPresent(Subscribe.class) || m.getParameterCount() != 1) continue;
            m.setAccessible(true);
            HANDLERS.computeIfAbsent(m.getParameterTypes()[0], k -> new CopyOnWriteArrayList<>())
                    .add(new Handler(o, m));
        }
    }

    public static void unregister(Object o) {
        HANDLERS.values().forEach(l -> l.removeIf(h -> h.owner == o));
    }

    public static <E extends Event> E post(E event) {
        List<Handler> list = HANDLERS.get(event.getClass());
        if (list == null) return event;
        for (Handler h : list) {
            try { h.method.invoke(h.owner, event); }
            catch (Exception ex) { ex.printStackTrace(); }
        }
        return event;
    }
}
