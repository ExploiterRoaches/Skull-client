package com.example.utilclient.module.combat;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.event.Subscribe;
import com.example.utilclient.event.TickEvent;
import com.example.utilclient.setting.NumberSetting;
import com.example.utilclient.util.Stopwatch;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

@ModuleInfo(name = "AutoHeal", category = Category.COMBAT, desc = "AutoSoup equivalent: eats healing items when low.")
public class AutoHeal extends Module {
    private final NumberSetting health = add(new NumberSetting("HealthBelow", 10, 1, 19, 1));
    private final NumberSetting delay  = add(new NumberSetting("Delay(ms)", 300, 50, 2000, 10));
    private final Stopwatch timer = new Stopwatch();
    private int prevSlot = -1;

    @Subscribe
    private void onTick(TickEvent e) {
        // restore the previous hotbar slot once the item is finished
        if (prevSlot != -1 && !mc.player.isUsingItem()) {
            mc.player.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
        if (mc.player.getHealth() > health.f() || mc.player.isUsingItem() || !timer.passed(delay.i())) return;

        for (int i = 0; i < 9; i++) {
            if (!isHealItem(mc.player.getInventory().getStack(i))) continue;
            prevSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = i;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            timer.reset();
            return;
        }
    }

    private boolean isHealItem(ItemStack s) {
        return s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.MUSHROOM_STEW)
            || s.isOf(Items.RABBIT_STEW) || s.isOf(Items.BEETROOT_SOUP);
    }
}
