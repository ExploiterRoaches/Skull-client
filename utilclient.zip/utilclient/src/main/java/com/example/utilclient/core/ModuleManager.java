package com.example.utilclient.core;

import com.example.utilclient.module.combat.AutoArmor;
import com.example.utilclient.module.combat.AutoHeal;
import com.example.utilclient.module.combat.KillAura;
import com.example.utilclient.module.movement.Fly;
import com.example.utilclient.module.movement.Speed;
import com.example.utilclient.module.movement.Sprint;
import com.example.utilclient.module.render.ESP;
import com.example.utilclient.module.render.Fullbright;
import com.example.utilclient.module.render.HUD;
import com.example.utilclient.module.render.XRay;
import com.example.utilclient.module.world.Scaffold;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final boolean[] KEY_DOWN = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private ModuleManager() {}

    /** Array-registered: add new modules here. */
    public static void init() {
        MODULES.addAll(List.of(
            new KillAura(), new AutoArmor(), new AutoHeal(),
            new ESP(), new XRay(), new Fullbright(), new HUD(),
            new Scaffold(),
            new Sprint(), new Fly(), new Speed()
        ));
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        return MODULES.stream().filter(m -> m.category == c).toList();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        throw new IllegalArgumentException("Module not registered: " + type);
    }

    /** Edge-detected keybind polling (no keyboard mixin needed). Call once per tick. */
    public static void pollKeys(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        long handle = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            if (m.key <= 0 || m.key > GLFW.GLFW_KEY_LAST) continue;
            boolean pressed = InputUtil.isKeyPressed(handle, m.key);
            if (pressed && !KEY_DOWN[m.key]) m.toggle();
            KEY_DOWN[m.key] = pressed;
        }
    }
}
