package com.example.utilclient.module.render;

import com.example.utilclient.core.Category;
import com.example.utilclient.core.Module;
import com.example.utilclient.core.ModuleInfo;
import com.example.utilclient.core.ModuleManager;
import com.example.utilclient.event.RenderHudEvent;
import com.example.utilclient.event.Subscribe;
import net.minecraft.client.font.TextRenderer;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

@ModuleInfo(name = "HUD", category = Category.RENDER, desc = "Watermark and active-module list.")
public class HUD extends Module {
    @Subscribe
    private void onHud(RenderHudEvent e) {
        if (mc.options.hudHidden) return;
        TextRenderer font = mc.textRenderer;
        int width = mc.getWindow().getScaledWidth();
        e.ctx.drawTextWithShadow(font, "UtilClient", 4, 4, 0xFF55FFFF);

        List<Module> active = ModuleManager.all().stream()
            .filter(Module::isEnabled).filter(m -> m != this)
            .sorted(Comparator.comparingInt((Module m) -> font.getWidth(label(m))).reversed())
            .toList();

        int y = 4;
        long t = System.currentTimeMillis();
        for (Module m : active) {
            String s = label(m);
            int x = width - font.getWidth(s) - 4;
            e.ctx.fill(x - 2, y - 1, width, y + 9, 0x90000000);
            int color = Color.HSBtoRGB(((y * 0.01f) + (t % 4000) / 4000f) % 1f, 0.6f, 1f);
            e.ctx.drawTextWithShadow(font, s, x, y, color);
            y += 10;
        }
    }

    private String label(Module m) {
        return m.hudSuffix().isEmpty() ? m.name : m.name + " \u00a77" + m.hudSuffix();
    }
}
