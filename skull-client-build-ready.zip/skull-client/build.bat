@echo off
setlocal
cd /d "%~dp0"
set "GRADLE_VERSION=8.10"
set "GRADLE_HOME=%USERPROFILE%\.gradle\local-gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip' '%USERPROFILE%\.gradle\local-gradle-%GRADLE_VERSION%-extract'; Move-Item -Force '%USERPROFILE%\.gradle\local-gradle-%GRADLE_VERSION%-extract\gradle-%GRADLE_VERSION%' '%GRADLE_HOME%'; Remove-Item -Recurse -Force '%USERPROFILE%\.gradle\local-gradle-%GRADLE_VERSION%-extract' -ErrorAction SilentlyContinue"
  if errorlevel 1 (echo Gradle download failed. Check your internet connection. & pause & exit /b 1)
)
call "%GRADLE_HOME%\bin\gradle.bat" build
if errorlevel 1 (echo Build failed. See the errors above. & pause & exit /b 1)
echo.
echo Build successful! JAR is in build\libs\skullclient-1.0.0.jar
pause
